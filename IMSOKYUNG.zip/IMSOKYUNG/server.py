from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# 전역 변수로 각 기기의 데이터를 저장 (IP 주소를 기준으로 각 기기를 구분)
device_data = {}
relay_commands = {"1111": False, "2222": False, "3333": False}  # UID별 릴레이 상태

# 각 region 카운트 변수
region1_count = 0
region2_count = 0
region3_count = 0

# 각 region별 warning 카운트 (실시간 반영)
region1_warning = 0
region2_warning = 0
region3_warning = 0

# 각 region의 위험 상태를 저장
region1_danger = False
region2_danger = False
region3_danger = False

# 태그가 새로운 경우에만 카운트하는 함수 (IP 주소 기반으로 각 기기 관리)
last_received_id = {}

@app.route('/data', methods=['POST'])
def receive_data():
    global region1_count, region2_count, region3_count
    global region1_warning, region2_warning, region3_warning
    global region1_danger, region2_danger, region3_danger
    try:
        data = request.json
        if not data:
            return jsonify({"error": "No JSON data received"}), 400

        board_id = data.get('id', 'No ID received')  # UID
        ip_address = request.remote_addr  # 기기의 IP 주소
        warning = data.get('warning', False)  # Warning 여부 (True/False)

        # IP 주소를 기준으로 기기를 고유하게 구분
        if ip_address not in device_data:
            device_data[ip_address] = {
                "message": board_id,
                "pressure1": 0.0,
                "pressure2": 0.0,
                "warning": False
            }
            last_received_id[ip_address] = ""

        # 기기 데이터를 업데이트
        device_data[ip_address]['message'] = board_id
        device_data[ip_address]['pressure1'] = data.get('pressure1', 0.0)
        device_data[ip_address]['pressure2'] = data.get('pressure2', 0.0)
        device_data[ip_address]['warning'] = warning

        # 태그에 따른 region 결정
        if board_id == "1111":
            region = "region1"
        elif board_id == "2222":
            region = "region2"
        elif board_id == "3333":
            region = "region3"
        else:
            return jsonify({"error": "Invalid ID"}), 400

        # IP 주소별로 마지막으로 받은 ID와 비교하여 카운트 증가
        if board_id != last_received_id[ip_address] and board_id != "0000":
            if region == "region1":
                region1_count += 1
                print(f"region1 count increased to {region1_count}")
            elif region == "region2":
                region2_count += 1
                print(f"region2 count increased to {region2_count}")
            elif region == "region3":
                region3_count += 1
                print(f"region3 count increased to {region3_count}")

            # 마지막으로 받은 ID를 업데이트
            last_received_id[ip_address] = board_id

        # 각 region별 warning 카운트는 실시간으로 반영 (누적 X)
        region1_warning = sum(1 for device in device_data.values() if device['message'] == "1111" and device['warning'])
        region2_warning = sum(1 for device in device_data.values() if device['message'] == "2222" and device['warning'])
        region3_warning = sum(1 for device in device_data.values() if device['message'] == "3333" and device['warning'])

        # 각 region의 위험 상태 확인 (절반 이상의 기기가 warning이면 danger 상태)
        region1_danger = region1_warning >= (region1_count / 2) if region1_count > 0 else False
        region2_danger = region2_warning >= (region2_count / 2) if region2_count > 0 else False
        region3_danger = region3_warning >= (region3_count / 2) if region3_count > 0 else False

        # 응답 보내기
        return jsonify({
            "status": "success",
            "received_data": data,
            "region1_count": region1_count,
            "region2_count": region2_count,
            "region3_count": region3_count,
            "region1_warning": region1_warning,
            "region2_warning": region2_warning,
            "region3_warning": region3_warning,
            "region1_danger": region1_danger,
            "region2_danger": region2_danger,
            "region3_danger": region3_danger,
            "device_data": device_data,
            "relay_commands": relay_commands  # UID별 릴레이 명령 상태 전달
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# 릴레이 제어 API (UID별 릴레이 상태 변경)
@app.route('/relay/<uid>', methods=['POST'])
def relay_control(uid):
    global relay_commands
    if uid not in relay_commands:
        return jsonify({"error": "Invalid UID"}), 400

    relay_state = request.json.get('state', False)
    relay_commands[uid] = relay_state  # 해당 UID에 대해 릴레이 상태 업데이트

    # 응답 보내기
    return jsonify({"status": "success", "uid": uid, "relay_state": relay_state}), 200

# 메시지 확인 엔드포인트 (웹에서 데이터 확인용)
@app.route('/message', methods=['GET'])
def get_message():
    return jsonify({
        "device_data": device_data,
        "region1_count": region1_count,
        "region2_count": region2_count,
        "region3_count": region3_count,
        "region1_warning": region1_warning,
        "region2_warning": region2_warning,
        "region3_warning": region3_warning,
        "region1_danger": region1_danger,
        "region2_danger": region2_danger,
        "region3_danger": region3_danger,
        "relay_commands": relay_commands  # 릴레이 명령 상태 추가
    })

# 웹 페이지를 렌더링하는 엔드포인트
@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
